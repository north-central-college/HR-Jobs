	<div id="masthead">
         <div id="masthead-top-left-container">
         	<a href="/"><img id="college_name" src="/sites/all/themes/ncc/images/north_central2.png" width="654" height="73" alt="North Central College - Naperville, IL" /></a>
         </div>
         <div id="masthead-top-right-container">
         <div>
         	<form id="cse-search-box" action="http://webapp.noctrl.edu/search">
         	<fieldset>             
         	<input size="18" id="q" name="q" type="text" />
         	<input id="sa" alt="search" src="/sites/all/themes/ncc/images/search.png" value="Search" name="sa" type="image" />
         	<input name="site" type="hidden" value="www" />
         	<input name="subnav" type="hidden" value="false" />
         	<input value="12713998885498363407:nk0o6v8si0a" name="cx" type="hidden" />
         	<input value="FORID:11" name="cof" type="hidden" />
         	<input value="UTF-8" name="ie" type="hidden" />
         	</fieldset>
         	</form>
         </div>
         <div>
         	<ul id="nav_verb">
         		<li><a href="https://www2.noctrl.edu/cgi-bin/applogin.pl"><img src="/sites/all/themes/ncc/images/nav_verb_apply.png" height="46" width="96" alt="Apply" /></a></li><li><a href="http://northcentralcollege.edu/admission/visit-programs"><img src="/sites/all/themes/ncc/images/nav_verb_visit.png" height="46" width="111" alt="Visit" /></a></li><li><a href="https://www.applyweb.com/public/contribute?nccgift"><img src="/sites/all/themes/ncc/images/nav_verb_give.png" height="46" width="107" alt="Give" /></a></li>
         	</ul>
         </div>
         </div>
         <div id="masthead-bottom">
         	
         		<ul id="nav_main"><li><a href="/admission"><img src="/sites/all/themes/ncc/images/nav_main_admission.png" height="60" width="118" alt="Admission" /></a></li><li><a href="http://northcentralcollege.edu/x23.xml"><img src="/sites/all/themes/ncc/images/nav_main_academics.png" height="60" width="105" alt="Academics" /></a></li><li><a href="/admission/graduate"><img src="/sites/all/themes/ncc/images/nav_main_graduatestudies.png" height="60" width="143" alt="Graduate Studies" /></a></li><li><a href="http://northcentralcollege.edu/show"><img src="/sites/all/themes/ncc/images/nav_main_finearts.png" height="60" width="93" alt="Fine Arts" /></a></li><li><a href="http://northcentralcardinals.com/"><img src="/sites/all/themes/ncc/images/nav_main_athletics.png" height="60" width="91" alt="Athletics" /></a></li><li><a href="http://northcentralcollege.edu/x143.xml"><img src="/sites/all/themes/ncc/images/nav_main_studentlife.png" height="60" width="111" alt="Student Life" /></a></li><li><a href="/alumni"><img src="/sites/all/themes/ncc/images/nav_main_alumni.png" height="60" width="103" alt="Alumni" /></a></li>
         		</ul>
         </div>
       </div>