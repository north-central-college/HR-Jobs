
</script> 

<?php 
$pageEmailURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageEmailURL .= "s";}
 $pageEmailURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageEmailURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageEmailURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
$httpOrHttps = 'http';
if ($_SERVER["HTTPS"] == "on") {
	$httpOrHttps = 'https';
}
?>
				<div id="footer-left">
        		<address>
          			<span>North Central College</span>
          			30 North Brainard Street<br />
          			Naperville, IL 60540<br />
          			630.637.5800
        		</address>
        		</div>
        		<div id="footer-right">
        		<ul id="utility">
          			<li><a href="javascript:window.print()">Print</a></li>
          			<li><a href="mailto:?subject=<?php print $title; ?>&body=<?php print $pageEmailURL?>">Email</a></li>
          			<li><a class="a2a_dd" href="http://www.addtoany.com/share_save">Share</a> 
					</li>
        		</ul>
        		<div id="footer-mission"><p>North Central College prepares students to be informed,
        			<br />involved, principled and productive citizens and leaders over their lifetime.
        		</p>
        		</div>
        		<div id="footer-links">
        		<ul>
          			<li><a href="http://northcentralcollege.edu/x8406.xml">Contact Us</a></li>
          			<li><a href="http://northcentralcollege.edu/x18670.xml">Mission Statement</a></li>
          			<li><a href="http://northcentralcollege.edu/x8405.xml">Copyright</a></li>
          			<li><a href="http://northcentralcollege.edu/x8405.xml">Legal Notice</a></li>
          			<li><a href="http://northcentralcollege.edu/x8643.xml">Privacy Policy</a></li>
        		</ul>
        		</div>
        		</div>
        		<div style="clear: both; "></div>
    <span id="thmr_135" class="thmr_call"> 
</span>
